<?php

$link = mysqli_connect("localhost", "root", "", "moshi_db");

